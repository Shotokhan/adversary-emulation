#pragma once

#define CFG_EN_ENFORCE_BREAKPOINT               (1)
