#pragma once

#include <tchar.h>

#include "kscldr.h"

#define KSCLDR_DESCRIPTION                          _T(KSCLDR_DESCRIPTION_A)
#define KSCLDR_SERVICE_NAME                         _T(KSCLDR_SERVICE_NAME_A)
#define KSCLDR_FILE_NAME                            _T(KSCLDR_FILE_NAME_A)
#define KSCLDR_LINK_NAME                            _T(KSCLDR_LINK_NAME_A)

#define DRIVER_DIR                                  _T("drivers")
